abstract class Service {
  protected int month;
  protected int day;
  protected int year;
  public Service(int month, int day, int year) {
    this.month = month;
    this.day = day;
    this.year = year;
  }
  public int getMonth() {
    return month;
  }
  public int getDay() {
    return day;
  }
  public int getYear() {
    return year;
  }
  public abstract void print();
}

class Appointment extends Service {
  // Members
  private String desc;

  // Constructors
  public Appointment(String desc, int month, int day, int year) {
    super(month, day, year);
    this.desc = desc;
  }
  // Getters
  public String getDesc() {
    return desc;
  }
  public void print() {
    System.out.print(month);
    System.out.print("/");
    System.out.print(day);
    System.out.print("/");
    System.out.println(year);
    System.out.print("\t");
    System.out.println(desc);
  };
}