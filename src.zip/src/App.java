import java.util.*;
import java.io.*;
class App {
  User selected;
  Vector<User> users;
  Scanner sc;
  Vector<Service> availableAppointments;
  public App() throws FileNotFoundException {
    sc = new Scanner(System.in);
    users = new Vector<User>();
    selected = null;
    availableAppointments = new Vector<Service>();
    loadAvailableAppointments();
    loadUsers();
  }

  private void loadUsers() throws FileNotFoundException {
    File text = new File("users.txt");
    Scanner usersc = new Scanner(text);
    while(usersc.hasNextLine()) {
            String line = usersc.nextLine();
            createUser(line);
    }  
    usersc.close();
  }
  private void loadAvailableAppointments() throws FileNotFoundException {
    File text = new File("app.txt");
    Scanner usersc = new Scanner(text);
    while(usersc.hasNextLine()) {
        int month = Integer.parseInt(usersc.nextLine());
        int day = Integer.parseInt(usersc.nextLine());
        int year = Integer.parseInt(usersc.nextLine());
        String desc = usersc.nextLine();
        createApp(desc, month, day, year);
    }
    usersc.close();
  }

  private void createUser(String name) {
    users.add(new User(name, new Vector<Service>()));
  }

  private void createApp(String desc, int month, int day, int year) {
    availableAppointments.add(new Appointment(desc, month, day, year));
  }

  private void printMenu() {
    System.out.print("Selected User: ");
    if(selected == null) {
      System.out.println("none");
    } else {
      System.out.println(selected.getName());
    }
    System.out.println("1. User Menu");
    System.out.println("2. Schedule an appointment");
    System.out.println("3. Exit");
    System.out.print(">> ");
  }

  private void selectUser() {
    System.out.println("=================");
    if(users.size() <= 0) {
      System.out.println("No users ... please make a user");
      System.out.println("=================");
      return;
    }
    for(int i = 0; i < users.size(); i++) {
      System.out.print(i+1);
      System.out.print(" ");
      System.out.println(users.get(i).getName());
    }
    System.out.println("Select a user");
    System.out.print(">> ");
    int n = sc.nextInt();
    if(n-1 < users.size()) {
      selected = users.get(n-1);
    } else {
      System.out.println("Not a valid option");
    }
    System.out.println("=================");
  }

  private void selectAppointment() {
    System.out.println("=================");
    if(availableAppointments.size() <= 0) {
      System.out.println("No appointments available.");
      System.out.println("=================");
      return;
    }
    for(int i = 0; i < availableAppointments.size(); i++) {
      System.out.print(i+1);
      System.out.print(" ");
      availableAppointments.get(i).print();
    }
    System.out.println("Select an appointment");
    System.out.print(">> ");
    int n = sc.nextInt();
    if(n-1 < availableAppointments.size()) {
      selected.addService(availableAppointments.get(n-1));
      availableAppointments.remove(n-1);
    } else {
      System.out.println("Not a valid option");
    }
    System.out.println("=================");
  }

  private void createUserMenu() {
    System.out.println("Please enter your name to create a new user.");
    System.out.print(">> ");
    sc.nextLine();
    String name = sc.nextLine();
    createUser(name);
  }

  private void printApps() {
    System.out.println("=================");
    if(selected == null) {
      System.out.println("No user is selected");
    } else {
      if(selected.getService().size() == 0) {
        System.out.println("You have no appointments at this time.");
      } else {
        for(int i = 0; i < selected.getService().size(); i++) {
          System.out.print(i+1);
          System.out.print(" ");
          selected.getService().get(i).print();
        }
      }
    }
    System.out.println("=================");
  }

  private void userMenu() {
    boolean isRunningUser = true;
    while(isRunningUser) {
      System.out.println("1. Select a user");
      System.out.println("2. Create a user");
      System.out.println("3. View appointments");
      System.out.println("4. Exit");
      System.out.print(">> ");
      int n = sc.nextInt();
      switch (n) {
        case(1):
          selectUser();
          break;
        case(2):
          createUserMenu();
          break;
        case(3):
          printApps();
          break;
        case(4):
          isRunningUser = false;
          break;
        default:
          System.out.println("Not a valid option");
          break;
      }
    }
  }

  private void appointmentMenu() {
    boolean isRunningAppointment = true;
    while(isRunningAppointment) {
      System.out.println("1. Select a Service");
      System.out.println("2. Exit");
      System.out.print(">> ");
      int n = sc.nextInt();
      switch (n) {
        case(1):
          selectAppointment();
          break;
        case(2):
          isRunningAppointment = false;
          break;
        default:
          System.out.println("Not a valid option");
          break;
      }
    }
  }

  public void run() {
    if(users.size() == 0) {
      System.out.println("No users were loaded.");
      System.out.println("Please enter your name to create a new user.");
      System.out.print(">> ");
      createUser(sc.nextLine());
      selected = users.get(0);
    }

    boolean isRunning = true;
    while(isRunning) {
      printMenu();
      int n = sc.nextInt();

      switch (n) {
        case(1):
          userMenu();
          break;
        case(2):
          appointmentMenu();
          break;
        case(3):
          isRunning = false;
          break;
        default:
          System.out.println("Not a valid option");
          break;
      }
    }
    System.out.println("Exiting...");
    sc.close();
  }

}