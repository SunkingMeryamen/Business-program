import java.util.*;

class User {
  private String name;
  private Vector<Service> services;
  public User(String name, Vector<Service> services) {
    this.name = name;
    this.services = services;
  }

  public String getName() {
    return name;   
  }

  public final Vector<Service> getService() {
    return services;
  }

  public final Service getService(int n) {
    return services.get(n);
  }

  public void removeService(int n) {
    services.remove(n);
  }

  public void addService(Service app) {
    services.add(app);
  }

  public boolean hasService() {
    return services.size() > 0;
  }
}